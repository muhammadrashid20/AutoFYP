"use strict";

const { authenticateRequest } = require("./auth");

exports.authenticateRequest = authenticateRequest;
