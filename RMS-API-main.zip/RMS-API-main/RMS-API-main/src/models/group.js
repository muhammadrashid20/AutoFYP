"use strict";

const mongoose = require("mongoose");
const { Schema } = mongoose;

const groupSchema = new Schema({
  _id: Schema["Types"].ObjectId,
  allotmentId: {
    type: Schema["Types"].ObjectId,
    ref: "Allotment",
  },
  cupboard: {
    type: Boolean,
    required: true,
  },
  sideTable: {
    type: Boolean,
    required: true,
  },
  name: {
    type: String,
    required: true,
  }
}, {
    timestamps: true,
});

const group = mongoose.model("group", groupSchema, "groups");

exports.group = group;

// groupID
// AllotmentNo
// Cupboard
// Side Table