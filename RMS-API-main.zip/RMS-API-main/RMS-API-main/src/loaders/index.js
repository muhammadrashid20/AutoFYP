"use strict";

exports.initializeServer = require("./server").initializeServer;
