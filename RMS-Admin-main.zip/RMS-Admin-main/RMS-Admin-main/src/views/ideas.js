
import React from "react";
import toast, { Toaster } from 'react-hot-toast';
import {Redirect} from 'react-router-dom';
import isAuthenticated from "../auth/index";
// reactstrap components
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
  Table,
} from "reactstrap";

class Idea extends React.Component {
    constructor(props) {
        super(props);
        // var showdate = new Date();                                                           // this is for showing date
        // var displaydate = showdate.getDate()+'/'+(showdate.getMonth()+1)+'/'+showdate.getFullYear();
        // var dt = showdate.toDateString();
        this.state = {
            ideasData:[],
            time: '',
            food: '',
            // date: showdate.toDateString(),
            InvalidLength: false,
        }
        this.handleSubmit = this.handleSubmit.bind(this);
        this.changeFood = this.changeFood.bind(this) ;
        this.changeTime = this.changeTime.bind(this) ;
        // this.changedate = this.changedate.bind(this) ;
        
    }
    componentDidMount(){
      this.setState({ideasData: this.props.ideasData});
    }
    //Validation
    changeFood(values) {
      var name = values.target.value ;
      if (name.length < 3 || name.length > 500) {
        this.setState({InvalidLength: true});
      }
      else {
        this.setState({InvalidLength: false});
      }
      this.setState({food: values.target.value});
    }
    changeDay(values){
      this.setState({day: values.target.value});
    }
    changeTime(values){
        this.setState({time: values.target.value});
    }
  //   changeDate(values){
  //     this.setState({date: values.target.value});
  // }

    async handleSubmit(values) {
      let tLoad = toast.loading("Adding New Ideas")
      values.preventDefault();
      if (
          this.state.InvalidLength === false &&
          this.state.time !== ''
       ){
        await this.props.postingIdeas(this.state.time, this.state.food);
        this.setState({ideasData: this.props.ideasData});
        this.setState({
          food: '',
          time: '',
        });
        
        
        toast.dismiss(tLoad);
        toast.success("New Idea Added");
      }
      
    }
    async handleDelete(data) {
      let tLoad = toast.loading("Deleting Idea") ;
      await this.props.deletingIdeas(data._id) ;
      this.setState({ideasData: this.props.ideasData});
      toast.dismiss(tLoad) ;
      toast.success("Idea Deleted");
    }
  render() {
    
    
    return (
      <>
        <div className="content">
        {!isAuthenticated(sessionStorage.getItem('HMS-Admin')) ? <Redirect to="/admin/login" /> : <></>}
          <Row>
            
            <Col md="12">
              <Card className="card-user">
                <CardHeader>
                  <CardTitle tag="h5">Give an Idea</CardTitle>
                </CardHeader>
                <CardBody>
                  <Toaster/>
                  <Form onSubmit={(values) => this.handleSubmit(values)}>
                    
                    <Row>
                        <Col className="pr-1" md="12">
                            <FormGroup>
                                <label>Idea Given by</label>
                                <Input
                                    placeholder="Teacher Name"
                                    type="text"
                                    onChange = {this.changeTime}
                                    value = {this.state.time}
                                    invalid = {this.state.InvalidLength}
                                  />
                            </FormGroup>
                        </Col>
                    </Row>
                    <Row>
                      <Col className="pr-1" md="12">
                        <FormGroup>
                          <label>Details</label>
                          <Input
                            placeholder="Details"
                            type="text"
                            onChange = {this.changeFood}
                            value = {this.state.food}
                            
                            invalid = {this.state.InvalidLength}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <div className="update ml-auto mr-auto">
                        <Button
                          className="btn-round"
                          color="primary"
                          type="submit"
                        >
                          Submit
                        </Button>
                      </div>
                    </Row>
                  </Form>
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col md="12">
              <Card>
                <CardHeader>
                  <CardTitle tag="h4">FYP Ideas</CardTitle>
                </CardHeader>
                <CardBody>
                  <Table responsive>
                    <thead className="text-primary">
                      <tr>
                        <th>Given by</th>
                        <th>Details</th>
                        {/* <th>Date</th> */}
                        <th>#</th>
                      </tr>
                    </thead>
                    <tbody>
                        {this.state.ideasData.map(((record) => {
                            return (
                                <>
                                <tr>
                                <td>{record.time}</td>
                                <td>{record.food}</td>
                                {/* <td>{record.date}</td> */}
                                <td><Button color="danger" onClick={() => this.handleDelete(record)} >Delete</Button></td>
                                </tr>
                                </>
                            );
                        }))}
                    </tbody>
                  </Table>
                </CardBody>
              </Card>
            </Col>
            
          </Row>
        </div>
      </>
    );
  }
}

export default Idea;
