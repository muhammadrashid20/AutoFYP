
import React from "react";
import toast, { Toaster } from 'react-hot-toast';
import {Redirect} from 'react-router-dom';
import isAuthenticated from "../auth/index";
// reactstrap components
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
  Table,
} from "reactstrap";

class Annoucement extends React.Component {
    constructor(props) {
        super(props);
        // var showdate = new Date();                                                           // this is for showing date
        // var displaydate = showdate.getDate()+'/'+(showdate.getMonth()+1)+'/'+showdate.getFullYear();
        // var dt = showdate.toDateString();
        this.state = {
            mealData:[],
            day: '', 
            time: '',
            food: '',
            // date: showdate.toDateString(),
            InvalidLength: false,
        }
        this.handleSubmit = this.handleSubmit.bind(this);
        this.changeFood = this.changeFood.bind(this) ;
        this.changeDay = this.changeDay.bind(this) ;
        this.changeTime = this.changeTime.bind(this) ;
        // this.changedate = this.changedate.bind(this) ;
        
    }
    componentDidMount(){
      this.setState({mealData: this.props.mealData});
    }
    //Validation
    changeFood(values) {
      var name = values.target.value ;
      if (name.length < 3 || name.length > 500) {
        this.setState({InvalidLength: true});
      }
      else {
        this.setState({InvalidLength: false});
      }
      this.setState({food: values.target.value});
    }
    changeDay(values){
      this.setState({day: values.target.value});
    }
    changeTime(values){
        this.setState({time: values.target.value});
    }
  //   changeDate(values){
  //     this.setState({date: values.target.value});
  // }

    async handleSubmit(values) {
      let tLoad = toast.loading("Adding New Annoucements")
      values.preventDefault();
      if (
          this.state.InvalidLength === false &&
          this.state.day !== '' &&
          this.state.time !== ''
       ){
        await this.props.postingMeal(this.state.day, this.state.time, this.state.food, this.state.date);
        this.setState({mealData: this.props.mealData});
        this.setState({
          food: '',
          time: '',
          day: '',
          // date:'',
        });
        
        
        toast.dismiss(tLoad);
        toast.success("New Annoucement Added");
      }
      
    }
    async handleDelete(data) {
      let tLoad = toast.loading("Deleting Annoucement") ;
      await this.props.deletingMeal(data._id) ;
      this.setState({mealData: this.props.mealData});
      toast.dismiss(tLoad) ;
      toast.success("Annoucement Deleted");
    }
  render() {
    
    
    return (
      <>
        <div className="content">
        {!isAuthenticated(sessionStorage.getItem('HMS-Admin')) ? <Redirect to="/admin/login" /> : <></>}
          <Row>
            
            <Col md="12">
              <Card className="card-user">
                <CardHeader>
                  <CardTitle tag="h5">Make Annoucements</CardTitle>
                </CardHeader>
                <CardBody>
                  <Toaster/>
                  <Form onSubmit={(values) => this.handleSubmit(values)}>
                    <Row>
                        <Col className="pr-1" md="12">
                            <FormGroup>
                                <label>Annoucement For</label>
                            <Input
                                type="select"
                                onChange = {this.changeDay}
                                value = {this.state.day}
                                required
                            >
                                <option value="" disabled selected>Select</option>
                                <option value="Students">Students</option>
                                <option value="Teachers">Teachers</option>
                            </Input>
                            </FormGroup>
                        </Col>
                    </Row>
                    <Row>
                        <Col className="pr-1" md="12">
                            <FormGroup>
                                <label>Title</label>
                                <Input
                                    placeholder="Title"
                                    type="text"
                                    onChange = {this.changeTime}
                                    value = {this.state.time}
                                    invalid = {this.state.InvalidLength}
                                  />
                            </FormGroup>
                        </Col>
                    </Row>
                    <Row>
                      <Col className="pr-1" md="12">
                        <FormGroup>
                          <label>Details</label>
                          <Input
                            placeholder="Details"
                            type="text"
                            onChange = {this.changeFood}
                            value = {this.state.food}
                            
                            invalid = {this.state.InvalidLength}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <div className="update ml-auto mr-auto">
                        <Button
                          className="btn-round"
                          color="primary"
                          type="submit"
                        >
                          Submit
                        </Button>
                      </div>
                    </Row>
                  </Form>
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col md="12">
              <Card>
                <CardHeader>
                  <CardTitle tag="h4">Annoucements</CardTitle>
                </CardHeader>
                <CardBody>
                  <Table responsive>
                    <thead className="text-primary">
                      <tr>
                        <th>Annoucement For</th>
                        <th>Title</th>
                        <th>Details</th>
                        {/* <th>Date</th> */}
                        <th>#</th>
                      </tr>
                    </thead>
                    <tbody>
                        {this.state.mealData.map(((record) => {
                            return (
                                <>
                                <tr>
                                <td>{record.day}</td>
                                <td>{record.time}</td>
                                <td>{record.food}</td>
                                {/* <td>{record.date}</td> */}
                                <td><Button color="danger" onClick={() => this.handleDelete(record)} >Delete</Button></td>
                                </tr>
                                </>
                            );
                        }))}
                      
                    </tbody>
                  </Table>
                </CardBody>
              </Card>
            </Col>
            
          </Row>
        </div>
      </>
    );
  }
}

export default Annoucement;
